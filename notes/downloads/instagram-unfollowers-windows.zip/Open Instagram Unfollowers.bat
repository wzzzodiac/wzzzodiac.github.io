@echo off
setlocal
title Instagram Unfollowers
set "IG_UNFOLLOWERS_SCRIPT=%~dp0instagram-readonly.txt"
set "IG_UNFOLLOWERS_CHECK=0"
if /i "%~1"=="--check" set "IG_UNFOLLOWERS_CHECK=1"

powershell.exe -NoLogo -NoProfile -STA -Command "$ErrorActionPreference = 'Stop'; try { $scriptPath = $env:IG_UNFOLLOWERS_SCRIPT; if (-not [IO.File]::Exists($scriptPath)) { throw 'instagram-readonly.txt is missing. Keep it in the same folder as this launcher.' }; $code = [IO.File]::ReadAllText($scriptPath, [Text.Encoding]::UTF8); if ([String]::IsNullOrWhiteSpace($code)) { throw 'The script file is empty.' }; if ($env:IG_UNFOLLOWERS_CHECK -eq '1') { Write-Host ('Script found: ' + $code.Length + ' characters. No browser or clipboard changes.'); exit 0 }; Set-Clipboard -Value $code; Start-Process 'https://www.instagram.com/'; exit 0 } catch { Write-Host ('Launcher error: ' + $_.Exception.Message); exit 1 }"
if errorlevel 1 goto failed
if /i "%~1"=="--check" exit /b 0

echo.
echo  INSTAGRAM UNFOLLOWERS
echo  --------------------
echo.
echo  STEP 1 - OPEN YOUR PROFILE
echo  Instagram.com has opened automatically in your default browser.
echo  Log in and go to your profile.
echo.
echo  STEP 2 - PASTE THE CODE
echo  Right-click the page, choose Inspect, then select Console.
echo  Shortcut: Ctrl+Shift+J opens the Console directly.
echo  The complete code is already copied to your clipboard.
echo  Press Ctrl+V to paste it, then press Enter.
echo.
echo  STEP 3 - ENJOY!
echo  Click RUN in the Instagram Unfollowers panel to start scanning.
echo.
echo  If an older panel is open, close it with X before pasting.
echo  If pasting is blocked, follow the instructions in your Console.
echo  Use the same browser profile to keep your history and whitelist.
echo.
if /i "%~1"=="--no-pause" exit /b 0
echo  Press any key to exit . . .
pause >nul
exit /b 0

:failed
echo.
echo  Nothing was pasted or executed on Instagram.
if /i "%~1"=="--check" exit /b 1
if /i "%~1"=="--no-pause" exit /b 1
echo  Press any key to exit . . .
pause >nul
exit /b 1
